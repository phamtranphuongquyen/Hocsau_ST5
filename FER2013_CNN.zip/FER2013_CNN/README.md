# Thực nghiệm 1 · So sánh ba CNN trên FER2013

**Sinh viên** Ngô Bảo Ly · 3123411185 · SV2

Thực nghiệm so sánh CNN-2, CNN-3 và CNN-4 trên bài toán nhận diện 7 biểu cảm khuôn mặt từ ảnh xám 48 × 48. Ba mô hình dùng cùng cách chia dữ liệu, tăng cường ảnh và cấu hình huấn luyện.

## Cài đặt trên Windows

Mở PowerShell trong thư mục chứa `train.py` và chạy:

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install torch torchvision --index-url https://download.pytorch.org/whl/cpu
.\.venv\Scripts\python.exe -m pip install numpy pandas pillow matplotlib scikit-learn
```

Lệnh trên cài PyTorch bản CPU. Thư mục `.venv` được tạo riêng trên máy.

## Chuẩn bị dữ liệu

1. Tải bản CSV từ [FER2013 trên Kaggle](https://www.kaggle.com/datasets/nicolejyt/facialexpressionrecognition) và giải nén.
2. Tạo thư mục `data` cùng cấp với `train.py`, rồi đặt file vào `data/fer2013.csv`. File cần có ba cột `emotion`, `pixels` và `Usage`.
3. Kiểm tra dữ liệu và xuất ảnh mẫu:

```powershell
.\.venv\Scripts\python.exe check_data.py
.\.venv\Scripts\python.exe dataset.py
```

| Tập | Số ảnh | Cách dùng |
|---|---:|---|
| Training | 28.709 | Huấn luyện và áp dụng tăng cường ảnh |
| PublicTest | 3.589 | Theo dõi validation loss và chọn checkpoint |
| PrivateTest | 3.589 | Đánh giá cuối cùng |

## Huấn luyện và đánh giá

Chạy lần lượt từng lệnh sau:

```powershell
.\.venv\Scripts\python.exe models.py
.\.venv\Scripts\python.exe train.py --model 2 --epochs 40
.\.venv\Scripts\python.exe train.py --model 3 --epochs 40
.\.venv\Scripts\python.exe train.py --model 4 --epochs 40
.\.venv\Scripts\python.exe evaluate.py
```

`models.py` kiểm tra đầu ra và xuất hình so sánh kiến trúc. `train.py` dùng Adam, learning rate 0,001 và batch size 64. Mỗi mô hình lưu `best.pt` tại epoch có validation loss thấp nhất và dừng sớm sau 7 epoch liên tiếp không cải thiện.

`evaluate.py` cần `best.pt`, `history.csv` và `learning_curves.png` trong cả ba thư mục `results/cnn_2_e40`, `results/cnn_3_e40` và `results/cnn_4_e40`. Nếu repo không kèm checkpoint, chạy ba lệnh train để tạo chúng trước khi đánh giá.

## Kết quả trên PrivateTest

| Mô hình | Số khối tích chập | Test Accuracy | Test Macro-F1 |
|---|---:|---:|---:|
| CNN-2 | 2 | 53,66% | 43,00% |
| CNN-3 | 3 | 64,22% | 57,00% |
| CNN-4 | 4 | **68,26%** | **64,69%** |

CNN-4 đạt kết quả cao nhất theo cả hai chỉ số trong lần thực nghiệm này.

| File kết quả | Nội dung |
|---|---|
| `cnn_architectures.png` | Bảng so sánh kiến trúc |
| `test_summary.csv`, `test_comparison.png` | Bảng và biểu đồ so sánh ba mô hình |
| `augmentation_examples.png` | Ảnh gốc và các biến thể tăng cường |
| `history.csv`, `learning_curves.png` | Loss và accuracy của train và validation theo epoch |
| `classification_report.csv`, `confusion_matrix.png` | Kết quả phân loại theo từng lớp |
| `last_conv_filters.png` | Minh họa trọng số lớp tích chập cuối |

File tổng hợp được chương trình xuất vào `results/`. Các hình và bảng riêng của từng mô hình nằm trong thư mục `cnn_*_e40` tương ứng.
